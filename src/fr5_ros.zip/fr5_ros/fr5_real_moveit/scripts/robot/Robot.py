class Robot:

    def __init__(self, ip: str):
        self.ip = ip
