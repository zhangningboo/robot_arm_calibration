# frcobot_python_sdk 

Introduction
-------------
The Python SDK for FR series cobots with Windows and Linux OS.

Documentation
----------------
Please see [Python SDK](https://fair-documentation.readthedocs.io/en/latest/SDKManual/python_intro.html)。