gcc version 9.4.0 (Ubuntu 9.4.0-1ubuntu1~20.04.1)
python version:Python3.8.10